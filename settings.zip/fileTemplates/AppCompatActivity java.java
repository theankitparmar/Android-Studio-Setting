#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

#parse("File Header.java")
#set($words = ${NAME.split(",")})
#set($reversedWords = [])
#foreach($word in $words)
  #set($trimmedWord = $word.trim())
  #if($trimmedWord)
    #set($reversedWord = "")
    #set($chars = $trimmedWord.toCharArray())
    #foreach($char in $chars)
      #set($reversedWord = $char + $reversedWord)
    #end
    #set($reversedWords = $reversedWords + $reversedWord)
  #end
#end
public class ${NAME} {

String mm = ${reversedWords.join("_").toLowerCase()}
}
