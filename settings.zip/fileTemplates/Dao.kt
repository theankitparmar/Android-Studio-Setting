#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
#parse("File Header.java")
@Dao
interface ${Model}Dao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(m${Model} :${Model})
    
    @Delete
    suspend fun delete(m${Model} :${Model})
    
    @Query("Select * from ${Model}")
    fun getAll${Model}(): LiveData<List<${Model}>>
    
    @Update
    suspend fun update(m${Model} :${Model})

}