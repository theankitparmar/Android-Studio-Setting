#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
#parse("File Header.java")

@Database(entities = arrayOf(${Model}::class), version = 1)
//@TypeConverters(${Model}Converter::class,${Model}Converter::class)
abstract class ${NAME}: RoomDatabase() {

    abstract fun get${Model}Dao(): ${Model}Dao

    companion object {
        private var INSTANCE: ${NAME}? = null
        fun getDatabase(context: Context): ${NAME} {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ${NAME}::class.java,
                    "${NAME}"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}