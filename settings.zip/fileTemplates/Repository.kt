#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
import androidx.lifecycle.LiveData
#parse("File Header.java")
class ${Model}Repository(private val m${Model}Dao: ${Model}Dao) {

  val all${Model} :LiveData<List<${Model}>> = m${Model}Dao.getAll${Model}()
    suspend fun insert${Model}(model:${Model}){
        m${Model}Dao.insert(model)
    }
    suspend fun update${Model}(model:${Model}){
        m${Model}Dao.update(model)
    }
   suspend fun delete${Model}(model:${Model}){
        m${Model}Dao.delete(model)
    }
}